#include <stdio.h>
#include <math.h>
#include <RcppEigen.h>

using Eigen::VectorXd;
using Eigen::VectorXi;
using Eigen::Map;
using namespace Rcpp;

const int UPDATENUM=20;

// [[Rcpp::depends(RcppEigen)]]

double max(double a, double b){
  if(a>b){
    return a;
  }else{
    return b;
  }
}

double min(double a, double b){
  if(a>b){
    return b;
  }else{
    return a;
  }
}

class sortedq{
private:
    std::vector<double> plus;
    std::vector<double> minus;
    int pluslen;
    int minuslen;
public:
    void sortq(NumericVector qi){
        int qilen=qi.size();
        int i=0;
        int j=0;
        int k=0;
        for(i=0;i<qilen;i++){
            if(qi[i]>0){
                k++;
            }
        }
        i=0;
        double qqplus[k+1];
        double qqminus[qilen-k+1];
        pluslen=k;
        minuslen=qilen-k;
        for(k=0;k<qilen;k++){
            if(qi[k]>0){
                while(i>0){
                    if(fabs(qi[k]-0.5)>fabs(qqplus[i-1]-0.5)){
                        break;
                    }else{
                        qqplus[i]=qqplus[i-1];
                        i=i-1;
                    }
                }
                qqplus[i]=fmin(qi[k],1-1e-15);
                i=k+1-j;
            }else{
                while(j>0){
                    if(fabs(qi[k]+0.5)>fabs(qqminus[j-1]-0.5)){
                        break;
                    }else{
                        qqminus[j]=qqminus[j-1];
                        j=j-1;
                    }
                }
                qqminus[j]=fmin(-qi[k],1-1e-15);
                j=k+1-i;
            }
        }
        for(i=0;i<pluslen;i++){
            plus.push_back(qqplus[i]);
        }
        plus.push_back(1-1e-15);
        pluslen=pluslen+1;
        for(i=0;i<minuslen;i++){
            minus.push_back(qqminus[i]);
        }
        minus.push_back(1-1e-15);
        minuslen=minuslen+1;
    }
    double hatfdr(int ik, int jk)
    {
        double temp1;
        temp1=(plus[ik-1]>1-plus[ik-1])?1-plus[ik-1]:plus[ik-1];
        double temp2;
        temp2=(minus[jk-1]>1-minus[jk-1])?1-minus[jk-1]:minus[jk-1];
        int temp3=0;
        int temp4=0;
        int i;
        for(i=0;i<pluslen-1;i++){
            if(plus[i]<temp1){
                temp3++;
            }
            if(plus[i]>(1-temp1)){
                temp4++;
            }
        }
        for(i=0;i<minuslen-1;i++){
            if(minus[i]<temp2){
                temp3++;
            }
            if(minus[i]>(1-temp2)){
                temp4++;
            }
        }
        return (1+temp3)/double(fmax(1,temp4));
    }
    void emll(VectorXd& para,double& qplus,double& qminus,const int ik,const int jk,const int update){
        double pi0=para[0];
        double alpha=para[1];
        double beta=para[2];
        double lam=para[3];
        double prell=0;
        double nowll=0;
        double temp,temp2,temp3,temp4;
        int i,ii,j;
        ii=0;
        double probprob[4][pluslen+minuslen-2];
        if(update>0){
          for(i=0;i<ik;i++){
            if(plus[i]>0.5){
              probprob[2][i]=1;
              probprob[3][i]=1;
            }else{
              probprob[2][i]=0;
              probprob[3][i]=0;
            }
          }
          for(j=0;j<jk;j++){
            if(minus[j]<0.5){
              probprob[2][j+pluslen-1]=1;
              probprob[3][j+pluslen-1]=1;
            }
            else{
              probprob[2][j+pluslen-1]=0;
              probprob[3][j+pluslen-1]=0;
            }
          }
          do{
            for(i=0;i<ik;i++){
              probprob[0][i]=((1-pi0)*lam*alpha*pow((plus[i]+1)/2,alpha-1)+(1-pi0)*(1-lam)*beta*pow((1-plus[i])/2,beta-1))/(pi0+(1-pi0)*lam*alpha*pow((plus[i]+1)/2,alpha-1)+(1-pi0)*(1-lam)*beta*pow((1-plus[i])/2,beta-1));
              probprob[1][i]=(1-pi0)*lam*alpha*pow((plus[i]+1)/2,alpha-1)/(pi0+(1-pi0)*lam*alpha*pow((plus[i]+1)/2,alpha-1)+(1-pi0)*(1-lam)*beta*pow((1-plus[i])/2,beta-1));
            }
            for(j=0;j<jk;j++){
              probprob[0][j+pluslen-1]=((1-pi0)*lam*alpha*pow((-minus[j]+1)/2,alpha-1)+(1-pi0)*(1-lam)*beta*pow((1+minus[j])/2,beta-1))/(pi0+(1-pi0)*lam*alpha*pow((-minus[j]+1)/2,alpha-1)+(1-pi0)*(1-lam)*beta*pow((1+minus[j])/2,beta-1));
              probprob[1][j+pluslen-1]=(1-pi0)*lam*alpha*pow((-minus[j]+1)/2,alpha-1)/(pi0+(1-pi0)*lam*alpha*pow((-minus[j]+1)/2,alpha-1)+(1-pi0)*(1-lam)*beta*pow((1+minus[j])/2,beta-1));
            }
            for(i=ik;i<(pluslen-1);i++){
              probprob[0][i]=1-2*pi0/(2*pi0+(1-pi0)*lam*alpha*pow((plus[i]+1)/2,alpha-1)+(1-pi0)*(1-lam)*beta*pow((1-plus[i])/2,beta-1)+(1-pi0)*lam*alpha*pow((2-plus[i])/2,alpha-1)+(1-pi0)*(1-lam)*beta*pow(plus[i]/2,beta-1));
              probprob[1][i]=((1-pi0)*lam*alpha*pow((plus[i]+1)/2,alpha-1)+(1-pi0)*lam*alpha*pow((2-plus[i])/2,alpha-1))/(2*pi0+(1-pi0)*lam*alpha*pow((plus[i]+1)/2,alpha-1)+(1-pi0)*(1-lam)*beta*pow((1-plus[i])/2,beta-1)+(1-pi0)*lam*alpha*pow((2-plus[i])/2,alpha-1)+(1-pi0)*(1-lam)*beta*pow(plus[i]/2,beta-1));
              probprob[2][i]=pow(1+max(plus[i],1-plus[i]),alpha-1)/(pow(1+plus[i],alpha-1)+pow(2-plus[i],alpha-1));
              probprob[3][i]=pow(1-max(plus[i],1-plus[i]),beta-1)/(pow(1-plus[i],beta-1)+pow(plus[i],beta-1));
            }
            for(j=jk;j<(minuslen-1);j++){
              probprob[0][j+pluslen-1]=1-2*pi0/(2*pi0+(1-pi0)*lam*alpha*pow((-minus[j]+1)/2,alpha-1)+(1-pi0)*(1-lam)*beta*pow((1+minus[j])/2,beta-1)+(1-pi0)*lam*alpha*pow((minus[j])/2,alpha-1)+(1-pi0)*(1-lam)*beta*pow((2-minus[j])/2,beta-1));
              probprob[1][j+pluslen-1]=((1-pi0)*lam*alpha*pow((1-minus[j])/2,alpha-1)+(1-pi0)*lam*alpha*pow(minus[j]/2,alpha-1))/(2*pi0+(1-pi0)*lam*alpha*pow((-minus[j]+1)/2,alpha-1)+(1-pi0)*(1-lam)*beta*pow((1+minus[j])/2,beta-1)+(1-pi0)*lam*alpha*pow(minus[j]/2,alpha-1)+(1-pi0)*(1-lam)*beta*pow((2-minus[j])/2,beta-1));
              probprob[2][j+pluslen-1]=pow(1+max(-minus[j],-1+minus[j]),alpha-1)/(pow(1-minus[j],alpha-1)+pow(minus[j],alpha-1));
              probprob[3][j+pluslen-1]=pow(1-max(-minus[j],-1+minus[j]),beta-1)/(pow(1+minus[j],beta-1)+pow(2-minus[j],beta-1));
            }
            temp=0;
            temp2=0;
            for(i=0;i<(pluslen+minuslen-2);i++){
              temp=temp+probprob[0][i];
              temp2=temp2+probprob[1][i];
            }
            pi0=1-temp/(pluslen+minuslen-2);
            lam=temp2/temp;
            temp3=0;
            temp4=0;
            for(i=0;i<(pluslen-1);i++){
              temp3=temp3+probprob[1][i]*probprob[2][i]*log((1+max(plus[i],1-plus[i]))/2)+probprob[1][i]*(1-probprob[2][i])*log((1+min(plus[i],1-plus[i]))/2);
              temp4=temp4+(probprob[0][i]-probprob[1][i])*probprob[3][i]*log((1-max(plus[i],1-plus[i]))/2)+(probprob[0][i]-probprob[1][i])*(1-probprob[3][i])*log((1-min(plus[i],1-plus[i]))/2);
            }
            for(i=(pluslen-1);i<(pluslen+minuslen-2);i++){
              temp3=temp3+probprob[1][i]*probprob[2][i]*log((1+max(-minus[i-pluslen+1],-1+minus[i-pluslen+1]))/2)+probprob[1][i]*(1-probprob[2][i])*log((1+min(-minus[i-pluslen+1],-1+minus[i-pluslen+1]))/2);
              temp4=temp4+(probprob[0][i]-probprob[1][i])*probprob[3][i]*log((1-max(-minus[i-pluslen+1],-1+minus[i-pluslen+1]))/2)+(probprob[0][i]-probprob[1][i])*(1-probprob[3][i])*log((1-min(-minus[i-pluslen+1],-1+minus[i-pluslen+1]))/2);
            }
            alpha=-temp2/temp3;
            beta=(temp2-temp)/temp4;
            prell=nowll;
            nowll=0;
            for(i=0;i<ik;i++){
              temp=1e-10+pi0+(1-pi0)*lam*alpha*pow((plus[i]+1)/2,alpha-1)+(1-pi0)*(1-lam)*beta*pow((1-plus[i])/2,beta-1);
              nowll=nowll+log(temp);
            }
            for(j=0;j<jk;j++){
              temp=1e-10+pi0+(1-pi0)*lam*alpha*pow((1-minus[j])/2,alpha-1)+(1-pi0)*(1-lam)*beta*pow((1+minus[j])/2,beta-1);
              nowll=nowll+log(temp);
            }
            for(i=ik;i<(pluslen-1);i++){
              temp=1e-10+2*pi0+(1-pi0)*lam*alpha*(pow((plus[i]+1)/2,alpha-1)+pow(1-plus[i]/2,alpha-1))+(1-pi0)*(1-lam)*beta*(pow((1-plus[i])/2,beta-1)+pow(plus[i]/2,beta-1));
              nowll=nowll+log(temp);
            }
            for(j=jk;j<(minuslen-1);j++){
              temp=1e-10+2*pi0+(1-pi0)*lam*alpha*(pow(minus[j]/2,alpha-1)+pow((1-minus[j])/2,alpha-1))+(1-pi0)*(1-lam)*beta*(pow((1+minus[j])/2,beta-1)+pow(1-minus[j]/2,beta-1));
              nowll=nowll+log(temp);         
            }
            ii=ii+1;
          } while ((fabs(prell-nowll)>0.00001)&&(ii<10000));
          para[0]=pi0;
          para[1]=alpha;
          para[2]=beta;
          para[3]=lam;
          qplus=probprob[0][ik];
          qminus=probprob[0][pluslen-1+jk];
        } else {
          qplus=1-2*pi0/(2*pi0+(1-pi0)*lam*alpha*pow((plus[ik]+1)/2,alpha-1)+(1-pi0)*(1-lam)*beta*pow((1-plus[ik])/2,beta-1)+(1-pi0)*lam*alpha*pow((2-plus[ik])/2,alpha-1)+(1-pi0)*(1-lam)*beta*pow(plus[ik]/2,beta-1));
          qminus=1-2*pi0/(2*pi0+(1-pi0)*lam*alpha*pow((-minus[jk]+1)/2,alpha-1)+(1-pi0)*(1-lam)*beta*pow((1+minus[jk])/2,beta-1)+(1-pi0)*lam*alpha*pow((minus[jk])/2,alpha-1)+(1-pi0)*(1-lam)*beta*pow((2-minus[jk])/2,beta-1));
        }
    }
};

int updatei(VectorXd& para,sortedq& q,const int ik,const int jk,const int update){
    double qplus=0;
    double qminus=0;
    q.emll(para,qplus,qminus,ik,jk,update);
    if(qplus<qminus){
        return 1;
    }else{
        return 2;
    }
}

// [[Rcpp::export]]
NumericVector rejSK(NumericVector qi, double minalpha)
{
    sortedq q;
    int update;
    q.sortq(qi);
    int i;
    int k=0;
    for(i=0;i<qi.size();i++){
        if(qi[i]>0){
            k++;
        }
    }
    VectorXd para(4);
    para << 0.5 , 0.5 , 0.5 , 0.5;
    int ik=1;
    int jk=1;
    int endend=0;
    int updategap=1;
    NumericVector res=(qi.size());
    for(i=0;i<qi.size();i++){
        res[i]=0;
    }
    i=0;
    while(!endend){
        if(ik>=k){
            jk=jk+1;
            res[i]=2;
            i++;
        }else if(jk>=(qi.size()-k)){
            ik=ik+1;
            res[i]=1;
            i++;
        }else{
            update=0;
            if(UPDATENUM>=(qi.size()-2)){
              update=1;
            } else {
            updategap=(qi.size()-2)/UPDATENUM;
              if(i % updategap==0){
                update=1;
              }
            }
            res[i]=updatei(para,q,ik,jk,update);
//            res[qi.size()+4*i]=para[0];
//            res[qi.size()+4*i+1]=para[1];
//            res[qi.size()+4*i+2]=para[2];
//            res[qi.size()+4*i+3]=para[3];
            if(res[i]==1){
                ik=ik+1;
            }else{
                jk=jk+1;
            }
            i++;
        }
        if(((ik>=k)&&(jk>=(qi.size()-k)))||(q.hatfdr(ik,jk)<=minalpha)){
            endend=1;
        }
    }
    return res;
}
