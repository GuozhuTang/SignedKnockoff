#' Thale cress seedlings data
#' 
#' Data from a microarray study to identify DE genes between two genotypes.
#'     For each microarray, a two-sample t-test is used, and the results can be summarized as 22810 observations of p-values and t-values.
#'    
#' @docType data
#' 
#' @format A data frame with the following two variables:
#' \describe{
#'     \item{pval}{the p-values given by the two-sample t-tests}
#'     \item{tval}{the test statistics given by the two-sample t-tests}
#' }
#' 
#' @keywords datasets
#' 
#' @references Jang et al. (2014) The Plant Journal 78: 591-603
#' (\href{https://www.ncbi.nlm.nih.gov/pubmed/24580679}{PubMed})
#' 
#' @examples
#' data(ThaleCress)
#' FDR=SignedKnockoff(ThaleCress$tval,p=ThaleCress$pval)$FDR
#' rejResult=(FDR<=0.1)
"ThaleCress"