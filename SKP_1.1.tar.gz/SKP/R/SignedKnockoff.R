#library(Rcpp)
#sourceCpp("SKP.cpp")

#An old version of sortqi
Old_sortqi=function(qi,res){
  qplus=qi[qi>=0]
  qminus=-qi[qi<0]
  qplus=qplus[order(abs(qplus-1/2))]
  qplus=pmin(qplus,1-1e-15)
  qplus=c(qplus,1-1e-15)
  qminus=qminus[order(abs(qminus-1/2))]
  qminus=pmin(qminus,1-1e-15)
  qminus=c(qminus,1-1e-15)
  ik=1
  jk=1
  hatfdr=(1+sum(qminus<min(qminus[jk],1-qminus[jk]))+sum(qplus<min(qplus[ik],1-qplus[ik])))/max(1,sum(qminus[-length(qminus)]>max(qminus[jk],1-qminus[jk]))+sum(qplus[-length(qplus)]>max(qplus[ik],1-qplus[ik])))
  resres=rbind(c(qplus[ik],qminus[jk],hatfdr))
  if(any(res!=0)){
    for(i in 1:sum(res!=0)){
      if(res[i]==1) ik=ik+1 else jk=jk+1
      hatfdr=(1+sum(qminus<min(qminus[jk],1-qminus[jk]))+sum(qplus<min(qplus[ik],1-qplus[ik])))/max(1,sum(qminus[-length(qminus)]>max(qminus[jk],1-qminus[jk]))+sum(qplus[-length(qplus)]>max(qplus[ik],1-qplus[ik])))
      resres=rbind(resres,c(qplus[ik],qminus[jk],hatfdr))
    }
  }
  resres
}

sortqi=function(qi,res){
  rejOrd=c()
  reve=rep(FALSE,length(qi))
  q=pmin(pmax(qi,1e-15-1),1-1e-15)
  qplusorder=order(abs(q-1/2))
  qminusorder=order(abs(q+1/2))
  ik=1
  jk=1
  if(ik>0){
    reve[qplusorder[1:ik]]=TRUE
  }
  if(jk>0){
    reve[qminusorder[1:jk]]=TRUE
  }
  hatfdr=function(q,reve){
    tempq=q[!reve]
    A=sum((tempq<1/2)&(tempq> -1/2))
    return((1+A)/max(1,length(tempq)-A))
  }
  qval=rep(Inf,length(qi))
  minfdp=hatfdr(q,reve)
  if(any(res!=0)){
    for(i in 1:sum(res!=0)){
      if(res[i]==1){
        ik=ik+1
        reve[qplusorder[ik]]=TRUE
        qval[qplusorder[ik]]=minfdp
        if(q[qplusorder[ik]]>1/2){
          rejOrd=c(rejOrd,qplusorder[ik])
        }
      }else{
        jk=jk+1
        reve[qminusorder[jk]]=TRUE
        qval[qminusorder[jk]]=minfdp
        if(q[qminusorder[jk]]< -1/2){
          rejOrd=c(rejOrd,qminusorder[jk])
        }
      }
      minfdp=min(minfdp,hatfdr(q,reve))
    }
  }
  rejOrd=c(rejOrd,which(!reve))
  if(length(rejOrd)>=1){
    rejOrd=rejOrd[length(rejOrd):1]
  }else{
    rejOrd=NULL
  }
  return(list(FDR=ifelse((q>1/2)|(q< -1/2),qval,Inf),rejOrder=rejOrd))
}



##An old version of SignedKnockoff
SK_Old=function(x,p=NULL,alphalist=0.1){
  if(!is.numeric(x)){
    stop("The test statistics are not numbers.")
  }
  if(is.null(p)){
    qi=sign(x)*(2*pnorm(abs(x))-1)
  }else{
    if(!is.numeric(p)||any(p < 0)||any(p > 1)){
      stop("The p-values are not numbers between 0 and 1.")
    }else{
      if(length(p)!=length(x)){
        stop("The number of p-values is not equal to that of test statistics.")
      }
    }
    qi=sign(x)*(1-p)
  }
  if(!is.numeric(alphalist)||any(alphalist < 0)||any(alphalist > 1)){
    stop("The list of nominal FDR levels are not numbers between 0 and 1.")
  }
  if(any(qi==-1)||any(qi==0)||any(qi==1)){
    warning("The method may not work properly when some of the p-values are exactly equal to 0 or 1.")
  }
  
  res=rejSK(qi,min(alphalist))
  resres=Old_sortqi(qi,res)
  result=c()
  threshold=c()
  for(i in 1:length(alphalist)){
    if(any(resres[,3]<=alphalist[i])){
      num=which(resres[,3]<=alphalist[i])[1]
      lower=-max(resres[num,2],1-resres[num,2])
      upper=max(resres[num,1],1-resres[num,1])
      result=rbind(result,(qi<lower)|(qi>upper))
      threshold=rbind(threshold,c(lower,upper))
    }
    else{
      result=rbind(result,rep(FALSE,length(qi)))
      threshold=rbind(threshold,c(-1,1))
    }
  }
  list(result,threshold)
}



#'Signed-knockoff procedure
#'
#'The signed-knockoff procedure is used to solve multiple hypothesis testing problems.
#'    The details of the algorithm is described in the paper "A powerful procedure to control the false discovery rate with directional information"
#'    by Zhaoyang Tian, Kun Liang and Pengfei Li.
#'    
#'@param x a vector containing the test statistics.
#'@param p a vector containing the p-values.
#'    It is not necessary if the distribution of \code{x} under null hypotheses is the standard normal distribution.
#'
#'@return a list containing the folowing two components:
#'\item{FDR}{A vector containing the estimated local FDR of each null hypothesis. The idea is from the concept of
#'  q-values from Storey (2002). The rejection rule of the signed-knockoff procedure is equivalent to thresholding on
#'  this value. Setting the nominal FDR level as \eqn{alpha}{\alpha} will reject all the null hypotheses with
#'  estimated local FDR smaller than or equal to \eqn{alpha}{\alpha}. See the example for further details.}
#'\item{rejOrder}{A vector containing the rejection priority given by the signed-knockoff procedure.
#'  For example, The null hypothesis at position \code{rejOrder[1]} should be rejected before any other 
#'  null hypothesis. And the \code{rejOrder[1]}th null hypothesis should be rejected after that rejection.}
#'
#'@references Storey (2002) A direct approach to false discovery rates. Journal of the Royal Statistical Society. Series B, 64(3): 479-498.
#'
#'
#'@examples
#'p1=0.15
#'p2=0.05
#'mu1=-3
#'mu2=3
#'m=5000
#'alpha=0.1
#'
#'temp=sample(c(0,1,2),m,prob=c(1-p1-p2,p1,p2),replace=TRUE)
#'t=rnorm(m)+mu1*(temp==1)+mu2*(temp==2)
#'FDR=SignedKnockoff(t)$FDR
#'rejresult=(FDR<=alpha)
#'
#'fdr=sum((rejresult)&(temp==0))/max(sum(rejresult),1)
#'power=sum((rejresult)&(temp!=0))/max(sum(temp!=0),1)
#'
#'@export

SignedKnockoff=function(x,p=NULL){
  if(!is.numeric(x)){
    stop("The test statistics are not numbers.")
  }
  if(all(x>0)||all(x<0)){
    stop("The test statistics do not contain any directional information. (They have the same signs.)")
  }
  if(is.null(p)){
    qi=sign(x)*(2*pnorm(abs(x))-1)
  }else{
    if(!is.numeric(p)||any(p < 0)||any(p > 1)){
      stop("The p-values are not numbers between 0 and 1.")
    }else{
      if(length(p)!=length(x)){
        stop("The number of p-values is not equal to that of test statistics.")
      }
    }
    qi=sign(x)*(1-p)
  }
  if(any(qi==-1)||any(qi==0)||any(qi==1)){
    warning("The method may not work properly when some of the p-values are exactly equal to 0 or 1.")
  }
  
  res=rejSK(qi,-1)
  return(sortqi(qi,res))
}

