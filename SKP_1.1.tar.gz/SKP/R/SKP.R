#' @details
#'    The package aims at solving multiple hypothesis testing problem.
#'    It contains one method: \code{\link{SignedKnockoff}}, an implementation of the signed-knockoff procedure.
#'    It also contains the two real datasets, \code{\link{ThaleCress}} and \code{\link{ProstateCancer}}, which are discussed in Section 5 in the paper.
#' @keywords internal
#' @import Rcpp RcppEigen
#' @importFrom Rcpp evalCpp
#' @importFrom stats pnorm
#' @docType package
#' @useDynLib SKP
"_PACKAGE"
#> [1] "_PACKAGE"
