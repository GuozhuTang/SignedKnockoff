#' Prostate cancer data
#' 
#' Data from a microarray study to identify DE genes between prostate cancer patients and healthy individuals.
#'     For each microarray, a two-sample t-test is used.
#'    
#' @docType data
#' 
#' @format A vector containing 6033 observations of z-values.
#'     The z-values are transformed from original test statistics in order to change the distribution of test statistics under null hypotheses to the standard normal distribution
#'     while maintaing the directional information.
#' 
#' @keywords datasets
#' 
#' @references Singh et al. (2002) Cancer Cell 1: 203-209
#' (\href{https://www.ncbi.nlm.nih.gov/pubmed/12086878}{PubMed})
#' 
#' @source
#' \url{http://statweb.stanford.edu/~ckirby/brad/LSI/datasets-and-programs/data/prostatedata.RData}
#' 
#' @examples
#' data(ProstateCancer)
#' RejectResult=(SignedKnockoff(ProstateCancer)$FDR<=0.1)
"ProstateCancer"